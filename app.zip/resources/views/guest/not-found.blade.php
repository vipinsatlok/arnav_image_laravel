@extends("layout")

@section("section")
<h1>Not FOund</h1>

@endsection