@extends("layout")


<!-- setting title of page -->
@section("title")
About page
@endsection


<!-- stating page section -->
@section("section")
@endsection