@extends("layout")

@section("section")
<h1>Contact Page</h1>

@endsection