<div class="w-full flex flex-col items-center justify-center">
    <h1 class="mb-10 text-4xl font-extrabold leading-none tracking-tight text-gray-900 md:text-5xl lg:text-6xl dark:text-white">Best <span class="text-blue-600 dark:text-blue-500">FREE PNG</span> Images Store.</h1>
</div>