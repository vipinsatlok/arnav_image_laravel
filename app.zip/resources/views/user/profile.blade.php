@extends("layout")

@section("section")
<h1>Profile Page</h1>

@endsection