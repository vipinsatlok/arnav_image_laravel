@extends("layout")

@section("section")
<h1>Admin Image Page</h1>

@endsection