@extends("layout")

@section("section")
<h1>Admin Page</h1>

@endsection