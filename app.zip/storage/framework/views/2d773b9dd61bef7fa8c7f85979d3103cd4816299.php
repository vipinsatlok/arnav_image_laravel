

<?php $__env->startSection("section"); ?>
<div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
    <?php echo $__env->make("include.banner", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("include.search", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("include.upload", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php if($images->count() > 0): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 md:gap-5">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make("include.imageCard", ['fileName' => $image->fileName, 'tags' => $image->tags, 'fileSize' => $image->fileSize, 'title' => $image->title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo $__env->make("include.pagination", ['images' => $images], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
    <div class="my-5 p-5 text-gray-600 flex w-full justify-center items-center">No Data Found</div>
    <?php endif; ?>



</div>
<script src="<?php echo e(asset('js/uploadImage.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vipin\OneDrive\Desktop\arnav-image-app\resources\views/guest/index.blade.php ENDPATH**/ ?>