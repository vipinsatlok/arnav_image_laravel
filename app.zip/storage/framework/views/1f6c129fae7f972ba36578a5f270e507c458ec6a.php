


<!-- setting title of page -->
<?php $__env->startSection("title"); ?>
About page
<?php $__env->stopSection(); ?>


<!-- stating page section -->
<?php $__env->startSection("section"); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vipin\OneDrive\Desktop\arnav-image-app\resources\views/guest/about.blade.php ENDPATH**/ ?>