<?php
$siteName = "DA Free Png";
$siteTitle = "Free PNG Download : Digital Apnao";
$siteDescription = "Discover a treasure trove of high-quality, free PNG images with transparent backgrounds at Da freepng. Explore and download stunning graphics for your creative projects effortlessly.";
$keyWords= "Da freepng, png, free png, digitalapnao png, download free png, free png images, transparent png, free png images, png download, download free png, hd png, high quality png";
$iconPath = "/images/icon.png";
$logoPath = "/images/logo.png";

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo e($siteDescription); ?>">
    <meta name="keywords" content="<?php echo e($keyWords); ?>">

    <!-- Open Graph (OG) meta tags for social media -->
    <meta property="og:title" content="<?php echo e($siteTitle); ?>">
    <meta property="og:description" content="<?php echo e($siteDescription); ?>">
    <meta property="og:image" content="<?php echo e(asset($iconPath)); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:type" content="image website">

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset($logoPath)); ?>" type="image/png">

    <!-- other links -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.css" rel="stylesheet" />
    <title><?php echo $__env->yieldContent("title", $siteTitle); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,900&display=swap');
    </style>

    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>

<body class="flex min-h-screen flex-col">

    <?php echo $__env->make("include.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="flex-1">
        <?php echo $__env->yieldContent("section"); ?>
    </main>
    <?php echo $__env->make("include.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="https://twitter.com/intent/tweet?url=<?php echo e(url()->current()); ?>&text=Your%20Tweet%20Text" target="_blank" rel="noopener noreferrer">
        Share on Twitter
    </a>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.js"></script>
</body>

</html><?php /**PATH C:\Users\vipin\OneDrive\Desktop\arnav-image-app\resources\views/layout.blade.php ENDPATH**/ ?>