

<?php $__env->startSection("section"); ?>
<h1>Profile Page</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vipin\OneDrive\Desktop\arnav-image-app\resources\views/user/profile.blade.php ENDPATH**/ ?>